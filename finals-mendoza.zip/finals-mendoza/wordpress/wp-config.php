<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finalsmendoza' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'H&jE{`dX#R[3B?Wy9qu][(]urb]6jEW0&T&9|C2:u97Kv1q3HDU3.o9brUa8?PX^' );
define( 'SECURE_AUTH_KEY',  'IOV$;b ,fRDMH<zYWB;?;dye0h>N-Y/3QlN&i>3XC< ]:-HgX[a`t1q-vNk?,sbQ' );
define( 'LOGGED_IN_KEY',    'Y+?;QL-mb8]7g5z5U]1uAqo[*:7(pf^KZ8eQL.r3EVmgQ|i]<k#U*/LJB3*ne#MI' );
define( 'NONCE_KEY',        '{#t.~Qce9ENP5H&sI=|3PG.6U<</j0U1B9^`ji]NxZHp`aj jnm!<j!r-3!,Q{e0' );
define( 'AUTH_SALT',        '(mN~7FE-VJptjnU?xO9w,!fn0Je[Tz3nXVEe$W1n4kKazTv8i,>62Fi7qpv]5W.D' );
define( 'SECURE_AUTH_SALT', 'h-o%)dciXQVR7^wB&]AsEoI=X,q}&yNVq2WxY$a_DP~uRB0JY4qBPBpGrFJ,~;e~' );
define( 'LOGGED_IN_SALT',   '6P`xp%/<<QzR|]6MD%w3Fx!]ad>I/1WE.Wo}v-0OE8ZH6NdBw=O+~Gx,_I`!/+bI' );
define( 'NONCE_SALT',       'xP[UCz1I`LfjP5XVN{`K0:d}zqa9XY?s:U,w9sI))AH/{{|*%uRv97aZef&qHx`)' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
